﻿namespace ANNEEEEEE_TH_09
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.topWearToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tShirtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.shirtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bottomWearToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pantsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.longPantsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.accessoriesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.shoesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.jewelleriesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.othersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.dgv_product = new System.Windows.Forms.DataGridView();
            this.pBox_item1 = new System.Windows.Forms.PictureBox();
            this.pbox_item2 = new System.Windows.Forms.PictureBox();
            this.pBox_item3 = new System.Windows.Forms.PictureBox();
            this.lb_item1 = new System.Windows.Forms.Label();
            this.lb_item2 = new System.Windows.Forms.Label();
            this.lb_item3 = new System.Windows.Forms.Label();
            this.lb_harga1 = new System.Windows.Forms.Label();
            this.lb_harga2 = new System.Windows.Forms.Label();
            this.lb_harga3 = new System.Windows.Forms.Label();
            this.btn_item1 = new System.Windows.Forms.Button();
            this.btn_item2 = new System.Windows.Forms.Button();
            this.btn_item3 = new System.Windows.Forms.Button();
            this.lb_subtotal = new System.Windows.Forms.Label();
            this.lb_total = new System.Windows.Forms.Label();
            this.txtbox_subtotal = new System.Windows.Forms.TextBox();
            this.txtbox_total = new System.Windows.Forms.TextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.btn_upload = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.txtbox_itemname = new System.Windows.Forms.TextBox();
            this.txtbox_itemprice = new System.Windows.Forms.TextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btn_add = new System.Windows.Forms.Button();
            this.btn_delete = new System.Windows.Forms.Button();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_product)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_item1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_item2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_item3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(32, 32);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.topWearToolStripMenuItem,
            this.bottomWearToolStripMenuItem,
            this.accessoriesToolStripMenuItem,
            this.othersToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(4, 1, 0, 1);
            this.menuStrip1.Size = new System.Drawing.Size(1221, 26);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // topWearToolStripMenuItem
            // 
            this.topWearToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tShirtToolStripMenuItem,
            this.shirtToolStripMenuItem});
            this.topWearToolStripMenuItem.Name = "topWearToolStripMenuItem";
            this.topWearToolStripMenuItem.Size = new System.Drawing.Size(86, 24);
            this.topWearToolStripMenuItem.Text = "Top Wear";
            // 
            // tShirtToolStripMenuItem
            // 
            this.tShirtToolStripMenuItem.Name = "tShirtToolStripMenuItem";
            this.tShirtToolStripMenuItem.Size = new System.Drawing.Size(136, 26);
            this.tShirtToolStripMenuItem.Text = "T-Shirt";
            this.tShirtToolStripMenuItem.Click += new System.EventHandler(this.tShirtToolStripMenuItem_Click);
            // 
            // shirtToolStripMenuItem
            // 
            this.shirtToolStripMenuItem.Name = "shirtToolStripMenuItem";
            this.shirtToolStripMenuItem.Size = new System.Drawing.Size(136, 26);
            this.shirtToolStripMenuItem.Text = "Shirt";
            this.shirtToolStripMenuItem.Click += new System.EventHandler(this.shirtToolStripMenuItem_Click);
            // 
            // bottomWearToolStripMenuItem
            // 
            this.bottomWearToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.pantsToolStripMenuItem,
            this.longPantsToolStripMenuItem});
            this.bottomWearToolStripMenuItem.Name = "bottomWearToolStripMenuItem";
            this.bottomWearToolStripMenuItem.Size = new System.Drawing.Size(111, 24);
            this.bottomWearToolStripMenuItem.Text = "Bottom Wear";
            // 
            // pantsToolStripMenuItem
            // 
            this.pantsToolStripMenuItem.Name = "pantsToolStripMenuItem";
            this.pantsToolStripMenuItem.Size = new System.Drawing.Size(163, 26);
            this.pantsToolStripMenuItem.Text = "Pants";
            this.pantsToolStripMenuItem.Click += new System.EventHandler(this.pantsToolStripMenuItem_Click);
            // 
            // longPantsToolStripMenuItem
            // 
            this.longPantsToolStripMenuItem.Name = "longPantsToolStripMenuItem";
            this.longPantsToolStripMenuItem.Size = new System.Drawing.Size(163, 26);
            this.longPantsToolStripMenuItem.Text = "Long Pants";
            this.longPantsToolStripMenuItem.Click += new System.EventHandler(this.longPantsToolStripMenuItem_Click);
            // 
            // accessoriesToolStripMenuItem
            // 
            this.accessoriesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.shoesToolStripMenuItem,
            this.jewelleriesToolStripMenuItem});
            this.accessoriesToolStripMenuItem.Name = "accessoriesToolStripMenuItem";
            this.accessoriesToolStripMenuItem.Size = new System.Drawing.Size(99, 24);
            this.accessoriesToolStripMenuItem.Text = "Accessories";
            // 
            // shoesToolStripMenuItem
            // 
            this.shoesToolStripMenuItem.Name = "shoesToolStripMenuItem";
            this.shoesToolStripMenuItem.Size = new System.Drawing.Size(163, 26);
            this.shoesToolStripMenuItem.Text = "Shoes";
            this.shoesToolStripMenuItem.Click += new System.EventHandler(this.shoesToolStripMenuItem_Click);
            // 
            // jewelleriesToolStripMenuItem
            // 
            this.jewelleriesToolStripMenuItem.Name = "jewelleriesToolStripMenuItem";
            this.jewelleriesToolStripMenuItem.Size = new System.Drawing.Size(163, 26);
            this.jewelleriesToolStripMenuItem.Text = "Jewelleries";
            this.jewelleriesToolStripMenuItem.Click += new System.EventHandler(this.jewelleriesToolStripMenuItem_Click);
            // 
            // othersToolStripMenuItem
            // 
            this.othersToolStripMenuItem.Name = "othersToolStripMenuItem";
            this.othersToolStripMenuItem.Size = new System.Drawing.Size(66, 24);
            this.othersToolStripMenuItem.Text = "Others";
            this.othersToolStripMenuItem.Click += new System.EventHandler(this.othersToolStripMenuItem_Click);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(32, 32);
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // dgv_product
            // 
            this.dgv_product.AllowUserToAddRows = false;
            this.dgv_product.AllowUserToDeleteRows = false;
            this.dgv_product.AllowUserToResizeColumns = false;
            this.dgv_product.AllowUserToResizeRows = false;
            this.dgv_product.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgv_product.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgv_product.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_product.Location = new System.Drawing.Point(591, 42);
            this.dgv_product.Margin = new System.Windows.Forms.Padding(2);
            this.dgv_product.Name = "dgv_product";
            this.dgv_product.RowHeadersWidth = 82;
            this.dgv_product.RowTemplate.Height = 33;
            this.dgv_product.Size = new System.Drawing.Size(471, 297);
            this.dgv_product.TabIndex = 2;
            // 
            // pBox_item1
            // 
            this.pBox_item1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.pBox_item1.Location = new System.Drawing.Point(3, 13);
            this.pBox_item1.Margin = new System.Windows.Forms.Padding(2);
            this.pBox_item1.Name = "pBox_item1";
            this.pBox_item1.Size = new System.Drawing.Size(150, 205);
            this.pBox_item1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pBox_item1.TabIndex = 3;
            this.pBox_item1.TabStop = false;
            // 
            // pbox_item2
            // 
            this.pbox_item2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.pbox_item2.Location = new System.Drawing.Point(181, 13);
            this.pbox_item2.Margin = new System.Windows.Forms.Padding(2);
            this.pbox_item2.Name = "pbox_item2";
            this.pbox_item2.Size = new System.Drawing.Size(144, 205);
            this.pbox_item2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbox_item2.TabIndex = 4;
            this.pbox_item2.TabStop = false;
            // 
            // pBox_item3
            // 
            this.pBox_item3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.pBox_item3.Location = new System.Drawing.Point(355, 13);
            this.pBox_item3.Margin = new System.Windows.Forms.Padding(2);
            this.pBox_item3.Name = "pBox_item3";
            this.pBox_item3.Size = new System.Drawing.Size(145, 205);
            this.pBox_item3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pBox_item3.TabIndex = 5;
            this.pBox_item3.TabStop = false;
            // 
            // lb_item1
            // 
            this.lb_item1.AutoSize = true;
            this.lb_item1.Location = new System.Drawing.Point(13, 238);
            this.lb_item1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lb_item1.Name = "lb_item1";
            this.lb_item1.Size = new System.Drawing.Size(57, 16);
            this.lb_item1.TabIndex = 6;
            this.lb_item1.Text = "lb_item1";
            // 
            // lb_item2
            // 
            this.lb_item2.AutoSize = true;
            this.lb_item2.Location = new System.Drawing.Point(195, 238);
            this.lb_item2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lb_item2.Name = "lb_item2";
            this.lb_item2.Size = new System.Drawing.Size(57, 16);
            this.lb_item2.TabIndex = 7;
            this.lb_item2.Text = "lb_item2";
            // 
            // lb_item3
            // 
            this.lb_item3.AutoSize = true;
            this.lb_item3.Location = new System.Drawing.Point(376, 241);
            this.lb_item3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lb_item3.Name = "lb_item3";
            this.lb_item3.Size = new System.Drawing.Size(57, 16);
            this.lb_item3.TabIndex = 8;
            this.lb_item3.Text = "lb_item3";
            // 
            // lb_harga1
            // 
            this.lb_harga1.AutoSize = true;
            this.lb_harga1.Location = new System.Drawing.Point(13, 272);
            this.lb_harga1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lb_harga1.Name = "lb_harga1";
            this.lb_harga1.Size = new System.Drawing.Size(67, 16);
            this.lb_harga1.TabIndex = 9;
            this.lb_harga1.Text = "lb_harga1";
            // 
            // lb_harga2
            // 
            this.lb_harga2.AutoSize = true;
            this.lb_harga2.Location = new System.Drawing.Point(195, 272);
            this.lb_harga2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lb_harga2.Name = "lb_harga2";
            this.lb_harga2.Size = new System.Drawing.Size(67, 16);
            this.lb_harga2.TabIndex = 10;
            this.lb_harga2.Text = "lb_harga2";
            // 
            // lb_harga3
            // 
            this.lb_harga3.AutoSize = true;
            this.lb_harga3.Location = new System.Drawing.Point(376, 275);
            this.lb_harga3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lb_harga3.Name = "lb_harga3";
            this.lb_harga3.Size = new System.Drawing.Size(67, 16);
            this.lb_harga3.TabIndex = 11;
            this.lb_harga3.Text = "lb_harga3";
            // 
            // btn_item1
            // 
            this.btn_item1.Location = new System.Drawing.Point(14, 306);
            this.btn_item1.Margin = new System.Windows.Forms.Padding(2);
            this.btn_item1.Name = "btn_item1";
            this.btn_item1.Size = new System.Drawing.Size(111, 29);
            this.btn_item1.TabIndex = 12;
            this.btn_item1.Text = "Add to Cart";
            this.btn_item1.UseVisualStyleBackColor = true;
            this.btn_item1.Click += new System.EventHandler(this.btn_item1_Click);
            // 
            // btn_item2
            // 
            this.btn_item2.Location = new System.Drawing.Point(196, 306);
            this.btn_item2.Margin = new System.Windows.Forms.Padding(2);
            this.btn_item2.Name = "btn_item2";
            this.btn_item2.Size = new System.Drawing.Size(111, 29);
            this.btn_item2.TabIndex = 13;
            this.btn_item2.Text = "Add to Cart";
            this.btn_item2.UseVisualStyleBackColor = true;
            this.btn_item2.Click += new System.EventHandler(this.btn_item2_Click);
            // 
            // btn_item3
            // 
            this.btn_item3.Location = new System.Drawing.Point(375, 308);
            this.btn_item3.Margin = new System.Windows.Forms.Padding(2);
            this.btn_item3.Name = "btn_item3";
            this.btn_item3.Size = new System.Drawing.Size(111, 29);
            this.btn_item3.TabIndex = 14;
            this.btn_item3.Text = "Add to Cart";
            this.btn_item3.UseVisualStyleBackColor = true;
            this.btn_item3.Click += new System.EventHandler(this.btn_item3_Click);
            // 
            // lb_subtotal
            // 
            this.lb_subtotal.AutoSize = true;
            this.lb_subtotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_subtotal.Location = new System.Drawing.Point(605, 362);
            this.lb_subtotal.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lb_subtotal.Name = "lb_subtotal";
            this.lb_subtotal.Size = new System.Drawing.Size(135, 29);
            this.lb_subtotal.TabIndex = 15;
            this.lb_subtotal.Text = "Sub-Total:";
            // 
            // lb_total
            // 
            this.lb_total.AutoSize = true;
            this.lb_total.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_total.Location = new System.Drawing.Point(660, 402);
            this.lb_total.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lb_total.Name = "lb_total";
            this.lb_total.Size = new System.Drawing.Size(80, 29);
            this.lb_total.TabIndex = 16;
            this.lb_total.Text = "Total:";
            // 
            // txtbox_subtotal
            // 
            this.txtbox_subtotal.Location = new System.Drawing.Point(742, 366);
            this.txtbox_subtotal.Margin = new System.Windows.Forms.Padding(2);
            this.txtbox_subtotal.Name = "txtbox_subtotal";
            this.txtbox_subtotal.Size = new System.Drawing.Size(154, 22);
            this.txtbox_subtotal.TabIndex = 17;
            // 
            // txtbox_total
            // 
            this.txtbox_total.Location = new System.Drawing.Point(742, 409);
            this.txtbox_total.Margin = new System.Windows.Forms.Padding(2);
            this.txtbox_total.Name = "txtbox_total";
            this.txtbox_total.Size = new System.Drawing.Size(154, 22);
            this.txtbox_total.TabIndex = 18;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(48, 33);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(136, 189);
            this.pictureBox1.TabIndex = 19;
            this.pictureBox1.TabStop = false;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btn_item3);
            this.panel1.Controls.Add(this.btn_item2);
            this.panel1.Controls.Add(this.btn_item1);
            this.panel1.Controls.Add(this.lb_harga3);
            this.panel1.Controls.Add(this.lb_harga2);
            this.panel1.Controls.Add(this.lb_harga1);
            this.panel1.Controls.Add(this.lb_item3);
            this.panel1.Controls.Add(this.lb_item2);
            this.panel1.Controls.Add(this.lb_item1);
            this.panel1.Controls.Add(this.pBox_item3);
            this.panel1.Controls.Add(this.pbox_item2);
            this.panel1.Controls.Add(this.pBox_item1);
            this.panel1.Location = new System.Drawing.Point(16, 50);
            this.panel1.Margin = new System.Windows.Forms.Padding(2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(524, 378);
            this.panel1.TabIndex = 22;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(69, 13);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(93, 16);
            this.label7.TabIndex = 20;
            this.label7.Text = "Upload Image";
            // 
            // btn_upload
            // 
            this.btn_upload.Location = new System.Drawing.Point(192, 4);
            this.btn_upload.Margin = new System.Windows.Forms.Padding(2);
            this.btn_upload.Name = "btn_upload";
            this.btn_upload.Size = new System.Drawing.Size(111, 26);
            this.btn_upload.TabIndex = 21;
            this.btn_upload.Text = "Upload";
            this.btn_upload.UseVisualStyleBackColor = true;
            this.btn_upload.Click += new System.EventHandler(this.btn_upload_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(201, 48);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(75, 16);
            this.label8.TabIndex = 23;
            this.label8.Text = "Item Name:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(201, 99);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(69, 16);
            this.label9.TabIndex = 24;
            this.label9.Text = "Item Price:";
            // 
            // txtbox_itemname
            // 
            this.txtbox_itemname.Location = new System.Drawing.Point(205, 66);
            this.txtbox_itemname.Margin = new System.Windows.Forms.Padding(2);
            this.txtbox_itemname.Name = "txtbox_itemname";
            this.txtbox_itemname.Size = new System.Drawing.Size(121, 22);
            this.txtbox_itemname.TabIndex = 26;
            this.txtbox_itemname.TextChanged += new System.EventHandler(this.txtbox_itemname_TextChanged);
            // 
            // txtbox_itemprice
            // 
            this.txtbox_itemprice.Location = new System.Drawing.Point(205, 123);
            this.txtbox_itemprice.Margin = new System.Windows.Forms.Padding(2);
            this.txtbox_itemprice.Name = "txtbox_itemprice";
            this.txtbox_itemprice.Size = new System.Drawing.Size(121, 22);
            this.txtbox_itemprice.TabIndex = 27;
            this.txtbox_itemprice.TextChanged += new System.EventHandler(this.txtbox_itemprice_TextChanged);
            this.txtbox_itemprice.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtbox_itemprice_KeyPress);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.btn_add);
            this.panel2.Controls.Add(this.txtbox_itemprice);
            this.panel2.Controls.Add(this.txtbox_itemname);
            this.panel2.Controls.Add(this.label9);
            this.panel2.Controls.Add(this.pictureBox1);
            this.panel2.Controls.Add(this.label8);
            this.panel2.Controls.Add(this.btn_upload);
            this.panel2.Controls.Add(this.label7);
            this.panel2.Location = new System.Drawing.Point(227, 432);
            this.panel2.Margin = new System.Windows.Forms.Padding(2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(389, 275);
            this.panel2.TabIndex = 28;
            // 
            // btn_add
            // 
            this.btn_add.Location = new System.Drawing.Point(205, 193);
            this.btn_add.Margin = new System.Windows.Forms.Padding(2);
            this.btn_add.Name = "btn_add";
            this.btn_add.Size = new System.Drawing.Size(111, 29);
            this.btn_add.TabIndex = 15;
            this.btn_add.Text = "Add to Cart";
            this.btn_add.UseVisualStyleBackColor = true;
            this.btn_add.Click += new System.EventHandler(this.btn_add_Click);
            // 
            // btn_delete
            // 
            this.btn_delete.Location = new System.Drawing.Point(969, 356);
            this.btn_delete.Name = "btn_delete";
            this.btn_delete.Size = new System.Drawing.Size(93, 32);
            this.btn_delete.TabIndex = 29;
            this.btn_delete.Text = "Delete";
            this.btn_delete.UseVisualStyleBackColor = true;
            this.btn_delete.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(1221, 706);
            this.Controls.Add(this.btn_delete);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.txtbox_total);
            this.Controls.Add(this.txtbox_subtotal);
            this.Controls.Add(this.lb_total);
            this.Controls.Add(this.lb_subtotal);
            this.Controls.Add(this.dgv_product);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_product)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_item1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_item2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_item3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem topWearToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tShirtToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem shirtToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bottomWearToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pantsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem longPantsToolStripMenuItem;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem accessoriesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem shoesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem jewelleriesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem othersToolStripMenuItem;
        private System.Windows.Forms.DataGridView dgv_product;
        private System.Windows.Forms.PictureBox pBox_item1;
        private System.Windows.Forms.PictureBox pbox_item2;
        private System.Windows.Forms.PictureBox pBox_item3;
        private System.Windows.Forms.Label lb_item1;
        private System.Windows.Forms.Label lb_item2;
        private System.Windows.Forms.Label lb_item3;
        private System.Windows.Forms.Label lb_harga1;
        private System.Windows.Forms.Label lb_harga2;
        private System.Windows.Forms.Label lb_harga3;
        private System.Windows.Forms.Button btn_item1;
        private System.Windows.Forms.Button btn_item2;
        private System.Windows.Forms.Button btn_item3;
        private System.Windows.Forms.Label lb_subtotal;
        private System.Windows.Forms.Label lb_total;
        private System.Windows.Forms.TextBox txtbox_subtotal;
        private System.Windows.Forms.TextBox txtbox_total;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button btn_upload;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtbox_itemname;
        private System.Windows.Forms.TextBox txtbox_itemprice;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btn_add;
        private System.Windows.Forms.Button btn_delete;
    }
}

